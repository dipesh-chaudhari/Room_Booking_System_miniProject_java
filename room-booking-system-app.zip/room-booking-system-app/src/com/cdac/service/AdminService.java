package com.cdac.service;

import com.cdac.dto.Admin;



public interface AdminService {
	void addAdmin(Admin admin);
	boolean findAdmin(Admin admin);
	void modifyAdmin(Admin admin);
	void removeAdmin(int adminId);
	Admin adminDetails(int adminId);
	boolean checkEmailId(Admin admin);
}
