package com.cdac.service;

import java.util.List;

import com.cdac.dto.AddRoom;

public interface AddRoomService {
	void addRoom(AddRoom room);
	void removeRoom(int roomId);
	AddRoom findRoom(int roomId);
	void modifyRoom(AddRoom room);
	List<AddRoom> selectAll(int roomId);

}
