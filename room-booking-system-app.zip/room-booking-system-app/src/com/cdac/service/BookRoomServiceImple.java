package com.cdac.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.BookRoomDao;

@Service
public class BookRoomServiceImple implements BookRoomService {

	@Autowired
	private BookRoomDao bookRoomDao;
	@Override
	public void addBookRoom(int bookRoomNo, String bookRoomName, String bookRoomType, int bookNoOfBed,
			int bookMaxAdults, int bookMaxChilds, float bookRent, int userId) {
		
		bookRoomDao.insertBookRoom(bookRoomNo, bookRoomName, bookRoomType, bookNoOfBed, bookMaxAdults, bookMaxChilds, bookRent, userId);
	}

}
