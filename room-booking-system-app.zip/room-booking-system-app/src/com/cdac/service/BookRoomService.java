package com.cdac.service;

public interface BookRoomService {
	void addBookRoom(int bookRoomNo,String bookRoomName,String bookRoomType,int bookNoOfBed,
			int bookMaxAdults,int bookMaxChilds,float bookRent,int userId);
}
