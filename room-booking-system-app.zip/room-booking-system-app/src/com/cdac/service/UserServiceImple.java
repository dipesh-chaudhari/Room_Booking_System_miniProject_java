package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.UserDao;
import com.cdac.dto.User;
@Service
public class UserServiceImple implements UserService {

	@Autowired
	private UserDao userDao;
	@Override
	public void addUser(User user) {
		userDao.insertUser(user);
		
	}

	@Override
	public boolean findUser(User user) {
		
		 return userDao.checkUser(user);
	}

	@Override
	public void modifyUser(User user) {
		userDao.updateUser(user);
		
	}

	@Override
	public void removeUser(int userId) {
		userDao.deleteUser(userId);
		
	}

	@Override
	public User userDetails(int userId) {
		
		return userDao.selectUser(userId);
	}

	@Override
	public String userForgotPassword(String userEmail) {
	
		return userDao.userForgotPassword(userEmail);
	}

	@Override
	public List<User> selectAll() {
		// return addRoomDao.selectAll(roomId);
		return userDao.selectAll();
	}

	@Override
	public boolean checkEmailId(User user) {
		
		return userDao.validEmailId(user);
	}

}
