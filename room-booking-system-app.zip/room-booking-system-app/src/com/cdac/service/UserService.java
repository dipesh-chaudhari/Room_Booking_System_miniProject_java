package com.cdac.service;



import java.util.List;


import com.cdac.dto.User;

public interface UserService {
	void addUser(User user);
	boolean findUser(User user);
	void modifyUser(User user);
	void removeUser(int userId);
	User userDetails(int userId);
	String userForgotPassword(String userEmail);
	List<User> selectAll();
	boolean checkEmailId(User user);
}
