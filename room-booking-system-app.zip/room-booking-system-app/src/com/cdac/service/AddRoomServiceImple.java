package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.AddRoomDao;
import com.cdac.dto.AddRoom;

@Service
public class AddRoomServiceImple implements AddRoomService {
	
	@Autowired
	private AddRoomDao addRoomDao;
	
	@Override
	public void addRoom(AddRoom room) {
		addRoomDao.insertRoom(room);
		
	}

	@Override
	public void removeRoom(int roomId) {
		addRoomDao.deleteRoom(roomId);
		
	}

	@Override
	public AddRoom findRoom(int roomId) {
		return addRoomDao.selectRoom(roomId);
	}

	@Override
	public void modifyRoom(AddRoom room) {
		addRoomDao.updateRoom(room);
		
	}

	@Override
	public List<AddRoom> selectAll(int roomId) {
		return addRoomDao.selectAll(roomId);
	}

}
