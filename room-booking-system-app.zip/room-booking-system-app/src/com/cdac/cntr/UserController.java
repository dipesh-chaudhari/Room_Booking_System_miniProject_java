package com.cdac.cntr;

import java.util.List;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.cdac.valid.UserValidator;
import com.cdac.dto.AddRoom;
import com.cdac.dto.User;
import com.cdac.service.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	@Autowired
	private UserValidator userValidator;
	@Autowired
	private MailSender mailSender;
	
	@RequestMapping(value ="/prep_reg_form.htm",method = RequestMethod.GET)
	public String preRegForm(ModelMap map) {
		map.put("user", new User());
		return "reg_form.jsp";
		
	} 
	
	@RequestMapping(value = "/reg.htm",method = RequestMethod.POST)
	public String resister(User user,BindingResult result, ModelMap map) {
		boolean a = userService.checkEmailId(user);
		String msg = "You are already registered Please Login..!";
		if(!a) {
			userService.addUser(user);
			msg= "You are Successfully registered Please Login..!";
			map.put("msg", msg);
			return"info.jsp";
		}else {
			map.put("msg", msg);
			return"info.jsp";
		}
	}
	
	@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("user", new User());
		return "login_form.jsp";
	}
	
	@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
	public String login(User user, BindingResult result, ModelMap map,HttpSession session) {
		String msg = "Invalid Login Credentials Please Try Again";
		userValidator.validate(user, result);
		if(result.hasErrors()) {
			return "login_form.jsp";
		}
		
		boolean b = userService.findUser(user);
		if (b) {
			session.setAttribute("user", user);
			return "home.jsp";

		} else {

			map.put("msg", msg);
			return "info.jsp";
		}
	} 
	
	@RequestMapping(value = "/user_logout.htm", method = RequestMethod.GET)
	public String prepLogout(HttpSession session) {

		session.removeAttribute("user");
		session.invalidate();

		return "index.jsp";
	}
	
	@RequestMapping(value = "/user_update_form.htm",method = RequestMethod.GET)
	public String userUpdateForm(@RequestParam int userId,ModelMap map) {
		
		User us = userService.userDetails(userId);
		map.put("user", us);
		
		return "user_update_form.jsp";
	}
	
	@RequestMapping(value = "/user_update.htm",method = RequestMethod.POST)
	public String userUpdate(User user,ModelMap map,HttpSession session) {
		
		int userId = ((User)session.getAttribute("user")).getUserId();
		user.setUserId(userId);
		userService.modifyUser(user);
			
		return "home.jsp";
	}
	
	@RequestMapping(value = "/user_forgot_pass.htm",method = RequestMethod.POST)
	public String userforgotPassword(@RequestParam String userEmail,ModelMap map) {		
		String pass = userService.userForgotPassword(userEmail);
		String msg = "you are not registered";
		if(pass!=null) {	
			
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("cdacmumbai3@gmail.com");  
	        message.setTo(userEmail);  
	        message.setSubject("Your password");  
	        message.setText(pass);  
	        //sending message   
	        mailSender.send(message);
			msg = "check the mail for password";
		}
		//map.put("msg", msg);
		return "home.jsp";
	}
	
	@RequestMapping(value = "/all_users_list.htm",method = RequestMethod.GET)
	public String alluserlist(ModelMap map) {
		
		List<User> li = userService.selectAll();
		map.put("userList",li);
		
		return "all_users_list.jsp";
	}
	
	@RequestMapping(value = "/user_delete.htm",method = RequestMethod.GET)
	public String userDelete(@RequestParam int userId,ModelMap map,HttpSession session) {
		String msg ="Account Deleted Successfully..!!";
		
		userService.removeUser(userId);
		
		session.removeAttribute("user");
		session.invalidate();
		

		map.put("msg", msg);
		return "info.jsp";
	}
	
}

