package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.AddRoom;
import com.cdac.service.AddRoomService;

@Controller
public class AddRoomController {
	
	@Autowired
	private AddRoomService addRoomService;
	
	@RequestMapping(value = "/prep_room_add_form.htm",method = RequestMethod.GET)
	public String prepRoomAddForm(ModelMap map) {
		map.put("room", new AddRoom());
		return "room_add_form.jsp";
	}
	
	@RequestMapping(value = "/room_add.htm",method = RequestMethod.POST)
	public String roomAdd(AddRoom room,HttpSession session,ModelMap map) {
		String msg ="Room Added Successfully..!!";
		
		addRoomService.addRoom(room);

		int roomId =1;
		List<AddRoom> li = addRoomService.selectAll(roomId);
		map.put("roomList",li);
		map.put("msg", msg);
		return "admin_room_list.jsp";
	}
	
	@RequestMapping(value = "/admin_room_list.htm",method = RequestMethod.GET)
	public String allRoom(ModelMap map,HttpSession session) {
		String msg ="";
		int roomId =1;
		List<AddRoom> li = addRoomService.selectAll(roomId);
		map.put("roomList",li);
		map.put("msg", msg);
		return "admin_room_list.jsp";
	}
	
	@RequestMapping(value = "/admin_room_delete.htm",method = RequestMethod.GET)
	public String roomDelete(@RequestParam int roomId,ModelMap map,HttpSession session) {
		String msg ="Room Deleted Successfully..!!";
		
		addRoomService.removeRoom(roomId); 
		
		int roomId1 = 1;
		List<AddRoom> li = addRoomService.selectAll(roomId1);
		map.put("roomList", li);
		map.put("msg", msg);
		return "admin_room_list.jsp";
	}
	
	@RequestMapping(value = "/admin_room_update_form.htm",method = RequestMethod.GET)
	public String expenseUpdateForm(@RequestParam int roomId,ModelMap map) {
		
		AddRoom rm = addRoomService.findRoom(roomId);
		map.put("room",rm);
		
		return "admin_room_update_form.jsp";
	}
	
	@RequestMapping(value = "/room_update.htm",method = RequestMethod.POST)
	public String expenseUpdate(AddRoom room,ModelMap map,HttpSession session) {
		
		String msg ="Room Updated Successfully..!!";
		
		addRoomService.modifyRoom(room);
		int roomId=1;
		List<AddRoom> li = addRoomService.selectAll(roomId);
		map.put("roomList", li);
		map.put("msg", msg);
		return "admin_room_list.jsp";
	}
	
	@RequestMapping(value = "/user_search_room.htm",method = RequestMethod.GET)
	public String userSearchRoom(ModelMap map,HttpSession session) {
		int roomId =1;
		List<AddRoom> li = addRoomService.selectAll(roomId);
		map.put("roomList",li);
		
		return "user_search_room.jsp";
	}
}
