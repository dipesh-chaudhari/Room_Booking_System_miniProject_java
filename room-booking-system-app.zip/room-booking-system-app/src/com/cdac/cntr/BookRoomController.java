package com.cdac.cntr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.AddRoom;
import com.cdac.service.BookRoomService;

@Controller
public class BookRoomController {
	
	@Autowired
	private BookRoomService bookRoomService;

	@RequestMapping(value = "/add_book_room.htm",method = RequestMethod.GET)
	public String prepBookRoomAddForm(@RequestParam int roomNo, String roomName, String roomType, int bed, int adults, int childs, float rent, int userId) {
		System.out.println("chacha");
		
		bookRoomService.addBookRoom(roomNo, roomName, roomType, bed, adults, childs, rent, userId);
		
		return "home.jsp";
	}
	//href="add_book_room.htm?roomNo=<%=rm.getRoomNo()%>&roomName=<%=rm.getRoomName()%>&roomType=<%=rm.getRoomType()%>&bed=<%=rm.getNoOfBed()%>&adults=<%=rm.getMaxAdults()%>&childs=<%=rm.getMaxChilds()%>&rent=<%=rm.getRent()%>&userId=<%=((User)session.getAttribute("user")).getUserId())%>" role="button">BOOK ROOM</a>

}
