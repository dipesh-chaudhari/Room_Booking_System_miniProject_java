package com.cdac.cntr;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Admin;

import com.cdac.service.AdminService;
import com.cdac.valid.AdminValidator;



@Controller
public class AdminController {
	@Autowired
	private AdminService adminService;
	@Autowired
	private AdminValidator adminValidator;
	
	@RequestMapping(value ="/admin_prep_reg_form.htm",method = RequestMethod.GET)
	public String adminPreRegForm(ModelMap map) {
		map.put("admin", new Admin());
		return "admin_reg_form.jsp";
		
	} 
	
	@RequestMapping(value = "/admin_reg.htm",method = RequestMethod.POST)
	public String adminRegister(Admin admin,BindingResult result, ModelMap map) {
		boolean a = adminService.checkEmailId(admin);
		String msg = "You are already registered Please Login..!";
		if(!a) {
			adminService.addAdmin(admin);
			msg= "You are Successfully registered Please Login..!";
			map.put("msg", msg);
			return"info.jsp";
		}else {
			map.put("msg", msg);
			return"info.jsp";
		}
	}	
	
	@RequestMapping(value = "/admin_prep_log_form.htm",method = RequestMethod.GET)
	public String adminPrepLogForm(ModelMap map) {
		map.put("admin", new Admin());
		return "admin_login_form.jsp";
	}
	
	@RequestMapping(value = "/admin_login.htm",method = RequestMethod.POST)
	public String login(Admin admin, BindingResult result, ModelMap map,HttpSession session) {
		String msg = "Invalid Login Credentials Please Try Again";
		adminValidator.validate(admin, result);
		if(result.hasErrors()) {
			return "admin_login_form.jsp";
		}
		
		boolean b = adminService.findAdmin(admin);

		if (b) {
			session.setAttribute("admin", admin);
			return "home.jsp";

		} else {

			map.put("msg", msg);
			return "info.jsp";
		}
	}
	
	@RequestMapping(value = "/admin_logout.htm", method = RequestMethod.GET)
	public String prepLogout(HttpSession session) {

		session.removeAttribute("admin");
		session.invalidate();

		return "index.jsp";
	}
	
	@RequestMapping(value = "/admin_update_form.htm",method = RequestMethod.GET)
	public String adminUpdateForm(@RequestParam int adminId,ModelMap map) {
		
		Admin ad = adminService.adminDetails(adminId);
		map.put("admin", ad);
		
		return "admin_update_form.jsp";
	}
	
	@RequestMapping(value = "/admin_update.htm",method = RequestMethod.POST)
	public String userUpdate(Admin admin,ModelMap map,HttpSession session) {
		
		int adminId = ((Admin)session.getAttribute("admin")).getAdminId();
		admin.setAdminId(adminId);
		adminService.modifyAdmin(admin);
			
		return "home.jsp";
	}
}
