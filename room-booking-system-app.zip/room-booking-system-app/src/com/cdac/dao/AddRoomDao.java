package com.cdac.dao;

import java.util.List;

import com.cdac.dto.AddRoom;

public interface AddRoomDao {
	void insertRoom(AddRoom room);
	void deleteRoom(int roomId);
	AddRoom selectRoom(int roomId);
	void updateRoom(AddRoom room);
	List<AddRoom> selectAll(int roomId);
}
