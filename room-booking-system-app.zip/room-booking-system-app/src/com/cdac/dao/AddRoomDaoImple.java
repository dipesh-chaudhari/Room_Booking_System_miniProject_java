package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.AddRoom;

@Repository
public class AddRoomDaoImple implements AddRoomDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertRoom(AddRoom room) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(room);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public void deleteRoom(int roomId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new AddRoom(roomId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public AddRoom selectRoom(int roomId) {
		AddRoom room = hibernateTemplate.execute(new HibernateCallback<AddRoom>() {

			@Override
			public AddRoom doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				AddRoom rm = (AddRoom)session.get(AddRoom.class, roomId);
				tr.commit();
				session.flush();
				session.close();
				return rm;
			}
			
		});
		return room;
	}

	@Override
	public void updateRoom(AddRoom room) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.update(room);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public List<AddRoom> selectAll(int roomId) {
		List<AddRoom> roomlist = hibernateTemplate.execute(new HibernateCallback<List<AddRoom>>() {

			@Override
			public List<AddRoom> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from AddRoom");
				List<AddRoom> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return roomlist;
	}

}
