package com.cdac.dao;

import com.cdac.dto.Admin;
import com.cdac.dto.User;


public interface AdminDao {
	void insertAdmin(Admin admin);
	boolean checkAdmin(Admin admin);
	void updateAdmin(Admin admin);
	void deleteAdmin(int adminId);
	Admin selectAdmin(int adminId);
	boolean validEmailId(Admin admin);
}
