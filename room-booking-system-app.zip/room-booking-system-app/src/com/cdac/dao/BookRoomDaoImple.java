package com.cdac.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class BookRoomDaoImple implements BookRoomDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertBookRoom(int bookRoomNo, String bookRoomName, String bookRoomType, int bookNoOfBed,
			int bookMaxAdults, int bookMaxChilds, float bookRent, int userId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				//Query q =session.createQuery("insert into BookRoom (bookRoomNo,bookRoomName,bookRoomType,bookNoOfBed,bookMaxAdults,bookMaxChilds,bookRent,userId)  values(?,?,?,?,?,?,?,?)");
				
				SQLQuery q = session.createSQLQuery("insert into BookRoom (bookRoomNo,bookRoomName,bookRoomType,bookNoOfBed,bookMaxAdults,bookMaxChilds,bookRent,userId) values(?,?,?,?,?,?,?,?)");
				q.setInteger(0, bookRoomNo);
				q.setString(1, bookRoomName);
				q.setString(2, bookRoomType);
				q.setInteger(3, bookNoOfBed);
				q.setInteger(4, bookMaxAdults);
				q.setInteger(5, bookMaxChilds);
				q.setFloat(6, bookRent);
				q.setInteger(7, userId);
				tr.commit();
				System.out.println("part 2");
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

}

//("insert into BookRoom(stock_code, stock_name)" +
//        "select stock_code, stock_name from backup_stock");

//(bookRoomNo,bookRoomName,bookRoomType,"
//+ "bookNoOfBed,bookMaxAdults,bookMaxChilds,bookRent,userId)

