package com.cdac.dao;

public interface BookRoomDao {
	void insertBookRoom(int bookRoomNo,String bookRoomName,String bookRoomType,int bookNoOfBed,
			int bookMaxAdults,int bookMaxChilds,float bookRent,int userId);
}
