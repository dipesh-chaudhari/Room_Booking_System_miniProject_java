package com.cdac.dao;



import java.util.List;


import com.cdac.dto.User;

public interface UserDao {
	void insertUser(User user);
	boolean checkUser(User user);
	void updateUser(User user);
	void deleteUser(int userId);
	User selectUser(int userId);
	String userForgotPassword(String userEmail);
	List<User> selectAll();
	boolean validEmailId(User user);
}
