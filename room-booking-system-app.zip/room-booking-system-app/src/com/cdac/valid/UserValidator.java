package com.cdac.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cdac.dto.User;




@Service
public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		
		return clazz.equals(User.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userEmail", "mailKey", "Email is Required..!!");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPass", "passKey", "Password is Required..!!");
		
		User user = (User) target;
		if(user.getUserPass()!= null) {
			if (user.getUserPass().length()<3) {
				errors.rejectValue("userPass", "passKey", "Password should be more than 3 charactor..");
			}
		}
		
	}

}

