package com.cdac.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cdac.dto.Admin;


@Service
public class AdminValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		
		return clazz.equals(Admin.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "adminEmpNo", "EmpKey", "Employee No is Required..!!");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "adminPass", "passKey", "Password is Required..!!");
		
		Admin admin = (Admin) target;
		if(admin.getAdminPass()!= null) {
			if (admin.getAdminPass().length()<3) {
				errors.rejectValue("adminPass", "passKey", "Password should be more than 3 charactor..");
			}
		}
	}	
}
