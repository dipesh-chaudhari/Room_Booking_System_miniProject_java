package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin_info")
public class Admin {
	
	@Id
	@GeneratedValue
	@Column(name = "ad_id")
	private int adminId;
	@Column(name = "ad_name")
	private String adminName;
	@Column(name = "ad_Email")
	private String adminEmail;
	@Column(name = "ad_emp_no")
	private String adminEmpNo;
	@Column(name = "ad_pass")
	private String adminPass;
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(int adminId) {
		super();
		this.adminId = adminId;
	}
	public Admin(int adminId, String adminName, String adminEmail, String adminEmpNo, String adminPass) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminEmail = adminEmail;
		this.adminEmpNo = adminEmpNo;
		this.adminPass = adminPass;
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
	public String getAdminEmpNo() {
		return adminEmpNo;
	}
	public void setAdminEmpNo(String adminEmpNo) {
		this.adminEmpNo = adminEmpNo;
	}
	public String getAdminPass() {
		return adminPass;
	}
	public void setAdminPass(String adminPass) {
		this.adminPass = adminPass;
	}
	@Override
	public String toString() {
		return  adminId + " " + adminName + " " + adminEmail + " "
				+ adminEmpNo + " " + adminPass ;
	}
	
	
	
	
}
