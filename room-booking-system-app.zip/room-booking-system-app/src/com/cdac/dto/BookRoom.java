package com.cdac.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bookroom")
public class BookRoom {
	@Id
	@GeneratedValue
	private int bookId;
	private int bookRoomNo;
	private String bookRoomName;
	private String bookRoomType;
	private int bookNoOfBed;
	private int bookMaxAdults;
	private int bookMaxChilds;
	private float bookRent;
	private int userId;
	public BookRoom() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookRoom(int bookId) {
		super();
		this.bookId = bookId;
	}
	public BookRoom(int bookId, int bookRoomNo, String bookRoomName, String bookRoomType, int bookNoOfBed,
			int bookMaxAdults, int bookMaxChilds, float bookRent, int userId) {
		super();
		this.bookId = bookId;
		this.bookRoomNo = bookRoomNo;
		this.bookRoomName = bookRoomName;
		this.bookRoomType = bookRoomType;
		this.bookNoOfBed = bookNoOfBed;
		this.bookMaxAdults = bookMaxAdults;
		this.bookMaxChilds = bookMaxChilds;
		this.bookRent = bookRent;
		this.userId = userId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public int getBookRoomNo() {
		return bookRoomNo;
	}
	public void setBookRoomNo(int bookRoomNo) {
		this.bookRoomNo = bookRoomNo;
	}
	public String getBookRoomName() {
		return bookRoomName;
	}
	public void setBookRoomName(String bookRoomName) {
		this.bookRoomName = bookRoomName;
	}
	public String getBookRoomType() {
		return bookRoomType;
	}
	public void setBookRoomType(String bookRoomType) {
		this.bookRoomType = bookRoomType;
	}
	public int getBookNoOfBed() {
		return bookNoOfBed;
	}
	public void setBookNoOfBed(int bookNoOfBed) {
		this.bookNoOfBed = bookNoOfBed;
	}
	public int getBookMaxAdults() {
		return bookMaxAdults;
	}
	public void setBookMaxAdults(int bookMaxAdults) {
		this.bookMaxAdults = bookMaxAdults;
	}
	public int getBookMaxChilds() {
		return bookMaxChilds;
	}
	public void setBookMaxChilds(int bookMaxChilds) {
		this.bookMaxChilds = bookMaxChilds;
	}
	public float getBookRent() {
		return bookRent;
	}
	public void setBookRent(float bookRent) {
		this.bookRent = bookRent;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "BookRoom [bookId=" + bookId + ", bookRoomNo=" + bookRoomNo + ", bookRoomName=" + bookRoomName
				+ ", bookRoomType=" + bookRoomType + ", bookNoOfBed=" + bookNoOfBed + ", bookMaxAdults=" + bookMaxAdults
				+ ", bookMaxChilds=" + bookMaxChilds + ", bookRent=" + bookRent + ", userId=" + userId + "]";
	}
	
	
}
