package com.cdac.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class AddRoom {
	@Id
	@GeneratedValue
	private int roomId;
	private int roomNo;
	private String roomName;
	private String roomType;
	private int noOfBed;
	private int maxAdults;
	private int maxChilds;
	private float rent;
	public AddRoom() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AddRoom(int roomId) {
		super();
		this.roomId = roomId;
	}
	public AddRoom(int roomId, int roomNo, String roomName, String roomType, int noOfBed, int maxAdults, int maxChilds,
			float rent) {
		super();
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomName = roomName;
		this.roomType = roomType;
		this.noOfBed = noOfBed;
		this.maxAdults = maxAdults;
		this.maxChilds = maxChilds;
		this.rent = rent;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public int getNoOfBed() {
		return noOfBed;
	}
	public void setNoOfBed(int noOfBed) {
		this.noOfBed = noOfBed;
	}
	public int getMaxAdults() {
		return maxAdults;
	}
	public void setMaxAdults(int maxAdults) {
		this.maxAdults = maxAdults;
	}
	public int getMaxChilds() {
		return maxChilds;
	}
	public void setMaxChilds(int maxChilds) {
		this.maxChilds = maxChilds;
	}
	public float getRent() {
		return rent;
	}
	public void setRent(float rent) {
		this.rent = rent;
	}
	@Override
	public String toString() {
		return  roomId + " " + roomNo + " " + roomName + " " + roomType
				+ " " + noOfBed + " " + maxAdults + " " + maxChilds + " " + rent ;
	}
	
	
}
