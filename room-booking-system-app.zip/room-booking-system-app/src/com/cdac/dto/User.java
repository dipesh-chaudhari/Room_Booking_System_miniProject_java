package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_info")
public class User {
	@Id
	@GeneratedValue
	@Column(name = "user_id")
	private int userId;
	@Column(name = "user_name")
	private String userName;
	@Column(name = "email")
	private String userEmail;
	@Column(name = "password")
	private String userPass;
	@Column(name = "adhar_no")
	private String adharNo;
	@Column(name = "mob_no")
	private String mobNo;
	private String address;
	private String city;
	private String state;
	private String pincode;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(int userId) {
		super();
		this.userId = userId;
	}
	public User(int userId, String userName, String userEmail, String userPass, String adharNo, String mobNo,
			String address, String city, String state, String pincode) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPass = userPass;
		this.adharNo = adharNo;
		this.mobNo = mobNo;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPass() {
		return userPass;
	}
	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}
	public String getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return userId + " " + userName + " " + userEmail + " "
				+ userPass + " " + adharNo + " " + mobNo + " " 
				+ address + " " + city + " " + state + " " + pincode;
	}

	
	
}
